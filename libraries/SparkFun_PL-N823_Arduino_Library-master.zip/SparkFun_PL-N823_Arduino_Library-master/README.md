SparkFun Qwiic PL-N823 IR Breakout
==================================

[![SparkFun Qwiic IR Breakout](https://cdn.sparkfun.com/assets/parts/1/4/4/2/8/15804-Qwiic_IR_Breakout-01.jpg)](https://cdn.sparkfun.com/assets/parts/1/4/4/2/8/15804-Qwiic_IR_Breakout-01.jpg)

[*SparkFun Qwiic IR Breakout (SPX-15804)*](https://www.sparkfun.com/products/15804)

Repository Contents
-------------------

* **/examples** - Measurement and peak-detection examples for the PL-N823

Documentation
-------------
* **[Installing an Arduino Library Guide](https://learn.sparkfun.com/tutorials/installing-an-arduino-library)** - Basic information on how to install an Arduino library.

License Information
-------------------

This product is _**open source**_!

Please review the LICENSE.md file for license information.

If you have any questions or concerns on licensing, please contact technical support on our [SparkFun forums](https://forum.sparkfun.com/viewforum.php?f=152).

Distributed as-is; no warranty is given.

- Your friends at SparkFun.

_<COLLABORATION CREDIT>_
